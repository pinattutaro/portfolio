let state = false;
let preLog = [];
const storageKey = "preLogForBackgroundOfObserve";

/*function setLog(log) {
    if(log.length == 0) return;
    const data = {};
    data[storageKey] = log;
    chrome.storage.local.set(data, () => {
        console.log('preLog was saved');
    });
}*/

function setLog(log) {
    return new Promise((resolve, reject) => {
        if(log.length == 0) resolve();
        const data = {};
        data[storageKey] = log;        

        chrome.storage.local.set(data, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError); // エラー処理
          } else {
            console.log('log was set.');
            resolve(); // 保存が成功した場合
          }
        });
    });
}

function getLog() {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get([storageKey], (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError); // エラー処理
        } else {
          resolve(result[storageKey]); // 成功した場合は取得したデータを解決
        }
      });
    });
  }

function connect() {
    const socket = new WebSocket('ws://192.168.1.19:8000');

    socket.onopen = function(event) {
        state = true;
        console.log("WebSocketが開かれました");

        getLog()
        .then(data => {
            preLog = data;
            const len = preLog.length;
            for(let i=0;i<len;i++) {
                socket.send(preLog.pop());//preLogはunshiftで挿入する。
            }
        })
        .catch(error => console.error(`it seems not to be able to get preLogs from chrome storage: ${error}`));
    };

    /*socket.onmessage = function(event) {



        // JSONメッセージを使って何か処理
        if (jsonData.type === 'greeting') {
            console.log("受信した挨拶:", jsonData.detail);
        }
    };*/

    socket.addEventListener('message', (event) => {
        const data = JSON.parse(event.data); // JSON文字列をオブジェクトに変換
        console.log("サーバーからのメッセージ:", data);

        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            //chrome.tabs.sendMessage(tabs[0].id, { message: "Hello from background!" });

            switch(data.type) {
                case "event": chrome.tabs.sendMessage(tabs[0].id ,event.data);
            }            
        });
    });

    socket.onclose = function(event) {
        state = false;
        console.log("サーバに接続できません");
        setLog(preLog)
        .then(() => {
            preLog = [];
            console.log(preLog);
            setTimeout(connect, 2000);
        })
        .catch(error => {
            console.error(`it seems not to be able to set preLog to chrome storage: ${error}`);
            setTimeout(connect, 2000);
        });            
    };

    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        //console.log(request);
        if(state) {
            socket.send(request);            
        } else {
            preLog.unshift(request);
            console.log(preLog);
        }

    });    
}

connect();